# 语料说明

这两份是 `air-writing-style` 技能的统计来源，纯文本，UTF-8。

| 文件 | 来源 | 规模 |
|---|---|---|
| `sygklisi.txt` | 《行于隙旅：Sygklisi》正文 | 1,776 行 / 128,705 字节 |
| `magic_nova.txt` | 《行于隙旅：杜纳米斯特辑》 | 154 行 / 9,343 字节 |

两份合计 37,677 汉字。原文为 Word（.docx），用下面的脚本从 `word/document.xml` 抽取段落文本，
**不含**批注、脚注、修订痕迹；图片与表格内文字也不会被抽出。

## 重新生成

```sh
mkdir -p x && cd x && unzip -o ../Sygklisi.docx word/document.xml
```

```python
from xml.etree import ElementTree as ET
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
tree = ET.parse('word/document.xml')
for p in tree.iter(W + 'p'):
    print(''.join(n.text or '' for n in p.iter() if n.tag == W + 't'))
```

## 用途

- 校准语气：想知道某句话该不该这么写，去语料里搜同类场景。
- 复算统计：`references/style-analysis.md` 里的数字都可以用 `wc`、`rg` 或几行 Python 复核。
